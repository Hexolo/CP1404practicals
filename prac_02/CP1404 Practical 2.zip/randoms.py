import random
print(random.randint(5, 20))
# Smallest: 3 Biggest: 17
print(random.randrange(3, 10, 2))
# Smallest: 5 Biggest: 9
print(random.uniform(2.5, 5.5))
# Smallest: 2.926006441047911 Biggest: 4.775823394171499
print(random.randrange(1, 100))